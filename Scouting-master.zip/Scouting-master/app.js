var actionList = [];
var compressedList = [];

var organizedActionList = new Array(3);

var teamNumber;

var matchNumber;

var powerCellCounter = 0;

var currentTable = 0;

var tables = ["table1", "table2", "table3", "QRCode"];

var moved = 0;

var comments;

var reviewSelection;

function init() {

  updateList();
  reviewSelection = document.getElementById("reviewSelection");

  /*  Only do this when you're going to the review section  
  
  document.getElementById("finalScoreLowNear").value=organizedActionList[0];
  
    document.getElementById("finalScoreHighNear").value=organizedActionList[1];
  
    document.getElementById("finalScoreLowFar").value=organizedActionList[2];
  
    document.getElementById("finalScoreHighFar").value=organizedActionList[3];
  
    */

  tables.forEach((x) => document.getElementById(x).style.display = "none");

  document.getElementById(tables[currentTable]).style.display = "block";




}

function updateList() {

  for (var i = 0; i < actionList.length; i++) {

    console.log("test");

    if (actionList[i] == "scoreLowNear") {

      organizedActionList[0]++;

    }

    else if (actionList[i] == "scoreHighNear") {

      organizedActionList[1]++;

    }

    else if (actionList[i] == "scoreLowFar") {

      organizedActionList[2]++;

    }

    else if (actionList[i] == "scoreHighFar") {

      organizedActionList[3]++;

    }

  }

}




function changeMatchNumber(number) {
  matchNumber = Math.min(number,999)
  console.log(matchNumber)
  document.getElementById("MatchNo1").value = matchNumber
  document.getElementById("MatchNo2").value = matchNumber
  document.getElementById("MatchNo3").value = matchNumber
}

function changeTeamNumber(number) {
  teamNumber = Math.min(number,99999)
  console.log(teamNumber)
  document.getElementById("teamNo1").value = number
  document.getElementById("teamNo2").value = number
  document.getElementById("teamNo3").value = number
  document.getElementById("teamNo4").value = number

}





function updateLog() {

  var logText = actionList.slice().reverse().join('\n');
  
  document.getElementById("teamLog1").value = logText;

  document.getElementById("teamLog2").value = logText;

  // document.getElementById("teamLog3").value = logText;

  document.getElementById("counter").innerHTML = '#' + powerCellCounter;

  document.getElementById("counter2").innerHTML = '#' + powerCellCounter;

  document.getElementById("counter2").innerHTML = '#' + powerCellCounter; //TODO: Remove line

  //let foulNumbers = 0;
  //actionList.forEach((e) => { if (e == "Foul" || e == "TechFoul") { foulNumbers++ } })

  //document.getElementById("foulsCount").innerHTML = foulNumbers;
  //console.log(foulNumbers)

  while(reviewSelection.children.length > 0){reviewSelection.removeChild(reviewSelection.children[0])}
  for(var i = 0; i < actionList.length; i++){
    reviewSelection.append(new Option(actionList[i],i,selected = false))
  }
  

}



function deleteActions() {
  if(reviewSelection.selectedOptions.length > 0){
    for(var i = 0; i < reviewSelection.selectedOptions.length; i++){
      actionList.splice(parseInt(reviewSelection.selectedOptions[i].value) - i,1)
      compressedList.splice(parseInt(reviewSelection.selectedOptions[i].value),1)
    }
  }
  updateLog()
}







//function changeTable(tableToShow){

// for(var i=0; i<tables.length;i++){

// 		if(i==tableToShow){

// 					document.getElementById(tables[i]).style.display = "block";

// 					continue;

// 		}

// 		document.getElementById(tables[i]).style.display = "none";

// 	}



// 	tableToShow = tableToShow % tables.length;

// }



function moveTableLeft() {



  console.log((currentTable - 1) % 2)

  document.getElementById(tables[currentTable]).style.display = "none";

  currentTable = currentTable - 1 < 0 ? tables.length - 1 : currentTable - 1;

  console.log(currentTable)

  document.getElementById(tables[currentTable]).style.display = "block";



}



function moveTableRight() {

  document.getElementById(tables[currentTable]).style.display = "none";

  //console.log(tables.length)

  currentTable = currentTable + 1 > tables.length - 1 ? 0 : currentTable + 1;

  console.log(currentTable)

  document.getElementById(tables[currentTable]).style.display = "block";



}


function tech() {
  console.log("Tech Foul");
  //techFoul = document.getElementById("techFo").value;
  foulCount++;
  updateLog()
}

function foul() {
  console.log("Foul");
  //foul = document.getElementById("Foul");
  foulCount++;
  updateLog()
}




// function changeTeamNumber()

// {

//   console.log("Team Number Recorded");

//   teamNumber = document.getElementById("TeamNo").value;



// }

// function changeMatchNumber()

// {

//   console.log("Match Number Recorded");

//   matchNumber = document.getElementById("MatchNo").value;

// }



function comments() {

  console.log("Comments Recorded");

  comments = document.getElementById("Comments").value;

}



function Undo() {

  console.log("Undo");


  var lastAction = actionList.pop();
  
  compressedList.pop();

  raiseCounter(lastAction, true);

  lowerCounter(lastAction, true);

  updateLog();

}



function addAction(action, number) {

  console.log(action);

  raiseCounter(action, false);

  lowerCounter(action, false);

  actionList.push(action);

  compressedList.push(number);

  updateLog();

}

function resetApp(){

  actionList = [];
  
  compressedList = [];

  changeMatchNumber(0);

  changeTeamNumber(0);

  powerCellCounter = 0;

  document.getElementById("comments").value = "";

  updateAvail();

  updateLog();

}



//This is a very ugly way of doing this I'm so sorry (it works though)

function raiseCounter(action, undoStatus) {

  if (action == "Pickup Near" || action == "Pickup Far") {

    if (undoStatus == true) {

      powerCellCounter--;

    }

    else {

      powerCellCounter++;

    }
    updateAvail()

  }

}

function lowerCounter(action, undoStatus) {

  if (action == "scoreHighNear" || action == "scoreHighFar" || action == "scoreLowNear" || action == "scoreLowFar" || action == "missLowNear" || action == "missLowFar" || action == "missHighNear" || action == "missHighFar" || action == "Drop" || action == "scoreHighNear2" || action == "scoreHighFar2" || action == "scoreLowNear2" || action == "scoreLowFar2" || action == "missLowNear2" || action == "missLowFar2" || action == "missHighNear2" || action == "missHighFar2" || action == "Drop2") {

    if (undoStatus == true) {

      powerCellCounter++;

    }

    else {

      powerCellCounter--;

    }
    updateAvail()

  }

}

function updateAvail(){

  if(powerCellCounter == 0){
    document.getElementById("scoreHighNear").disabled = true;
    document.getElementById("scoreLowNear").disabled = true;
    document.getElementById("scoreHighNear2").disabled = true;
    document.getElementById("scoreLowNear2").disabled = true;
    document.getElementById("missHighNear").disabled = true;
    document.getElementById("missLowNear").disabled = true;
    document.getElementById("missHighNear2").disabled = true;
    document.getElementById("missLowNear2").disabled = true;
    document.getElementById("scoreHighFar").disabled = true;
    document.getElementById("scoreLowFar").disabled = true;
    document.getElementById("scoreHighFar2").disabled = true;
    document.getElementById("scoreLowFar2").disabled = true;
    document.getElementById("missHighFar").disabled = true;
    document.getElementById("missLowFar").disabled = true;
    document.getElementById("missHighFar2").disabled = true;
    document.getElementById("missLowFar2").disabled = true;
    document.getElementById("Drop").disabled = true;
    document.getElementById("Drop2").disabled = true;
  } else {
    document.getElementById("scoreHighNear").disabled = false;
    document.getElementById("scoreLowNear").disabled = false;
    document.getElementById("scoreHighNear2").disabled = false;
    document.getElementById("scoreLowNear2").disabled = false;
    document.getElementById("missHighNear").disabled = false;
    document.getElementById("missLowNear").disabled = false;
    document.getElementById("missHighNear2").disabled = false;
    document.getElementById("missLowNear2").disabled = false;
    document.getElementById("scoreHighFar").disabled = false;
    document.getElementById("scoreLowFar").disabled = false;
    document.getElementById("scoreHighFar2").disabled = false;
    document.getElementById("scoreLowFar2").disabled = false;
    document.getElementById("missHighFar").disabled = false;
    document.getElementById("missLowFar").disabled = false;
    document.getElementById("missHighFar2").disabled = false;
    document.getElementById("missLowFar2").disabled = false;
    document.getElementById("Drop").disabled = false;
    document.getElementById("Drop2").disabled = false;
  }

}
